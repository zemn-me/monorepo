visibility("public")

{{name}} = {{value}}
